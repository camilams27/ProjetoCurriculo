/**
 */
var Crypto = {
}
/**
 * @syntax window.crypto.getRandomValues(typedArray);
 * @param {Array} typedArray
 * @returns {Array}
 * @static
 */
Crypto.getRandomValues = function(typedArray) {};

/**
 * Represents the Crypto prototype object.
 * @syntax Crypto.prototype
 * @static
 */
Crypto.prototype;

