/**
 * Represents the DocumentWindow's current location. The value MUST be the same as the Location for all views of the document.
 */
var Location = {
}
/**
 * @returns {undefined}
 */
Location.prototype.replace = function() {};

/**
 * @returns {DOMString}
 */
Location.prototype.port = new DOMString();

/**
 * @returns {undefined}
 */
Location.prototype.assign = function() {};

/**
 * @returns {DOMString}
 */
Location.prototype.protocol = new DOMString();

/**
 * @returns {DOMString}
 */
Location.prototype.host = new DOMString();

/**
 * @returns {DOMString}
 */
Location.prototype.search = new DOMString();

/**
 * @returns {DOMString}
 */
Location.prototype.hash = new DOMString();

/**
 * @returns {DOMString}
 */
Location.prototype.hostname = new DOMString();

/**
 * @returns {DOMString}
 */
Location.prototype.toString = function() {};

/**
 * @returns {DOMString}
 */
Location.prototype.pathname = new DOMString();

/**
 * @returns {undefined}
 */
Location.prototype.reload = function() {};

/**
 * @returns {DOMString}
 */
Location.prototype.href = new DOMString();

/**
 * Represents the Location prototype object.
 * @syntax Location.prototype
 * @static
 */
Location.prototype;

