/**
 */
var AbstractWorker = {
}
/**
 * @returns {undefined}
 */
AbstractWorker.prototype.onerror;

/**
 * Represents the AbstractWorker prototype object.
 * @syntax AbstractWorker.prototype
 * @static
 */
AbstractWorker.prototype;

