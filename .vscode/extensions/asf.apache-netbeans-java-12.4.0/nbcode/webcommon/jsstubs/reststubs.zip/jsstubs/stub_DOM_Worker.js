/**
 */
var Worker = {
}
/**
 * @syntax worker.postMessage(message, transferList);
 * @param {Object} message
 * @param {array|Transferable} transferList
 * @returns {undefined}
 */
Worker.prototype.postMessage = function(message,  transferList) {};

/**
 * @returns {undefined}
 */
Worker.prototype.terminate = function() {};

/**
 * @returns {undefined}
 */
Worker.prototype.onmessage;

/**
 * Represents the Worker prototype object.
 * @syntax Worker.prototype
 * @static
 */
Worker.prototype;

