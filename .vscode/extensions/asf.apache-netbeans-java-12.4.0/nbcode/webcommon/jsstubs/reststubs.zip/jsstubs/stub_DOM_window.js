/**
 */
var window = new Window();
/**
 * @returns {Window}
 * @static
 */
window.opener = new Window();

/**
 * @returns {Function}
 * @static
 */
window.onpageshow = new Function();

/**
 * @returns {Object}
 * @static
 */
window.personalbar = new Object();

/**
 * @syntax option = new window.Option(text, value, defaultSelected, selected)
 * @param {String} text
 * @param {String} value
 * @param {Boolean} defaultSelected
 * @param {Boolean} selected
 * @returns {HTMLOptionElement}
 * @static
 */
window.Option = function(text,  value,  defaultSelected,  selected) {};

/**
 * @syntax var immediateID = setImmediate(func, [param1, param2, ...]);<br>var immediateID = setImmediate(func);
 * @param {Function} func
 * @param {Object} 
 * @returns {immediateID}
 * @static
 */
window.setImmediate = function(func) {};

/**
 * @returns {Number}
 * @static
 */
window.scrollMaxX = new Number();

/**
 * @returns {Number}
 * @static
 */
window.scrollMaxY = new Number();

/**
 * @returns {Boolean}
 * @static
 */
window.fullScreen = new Boolean();

/**
 * @returns {Crypto}
 * @static
 */
window.crypto = new Crypto();

/**
 * @syntax var windowObjectReference = window.open(strUrl, strWindowName[, strWindowFeatures]);
 * @param {String} strUrl
 * @param {String} strWindowName
 * @returns {Window}
 * @static
 */
window.open = function(strUrl,  strWindowName) {};

/**
 * @syntax window.forward()
 * @returns {undefined}
 * @static
 */
window.forward = function() {};

/**
 * @returns {Function}
 * @static
 */
window.onpopstate = new Function();

/**
 * @returns {Function}
 * @static
 */
window.onpaint = new Function();

/**
 * @returns {Storage}
 * @static
 */
window.localStorage = new Storage();

/**
 * @syntax window.focus()
 * @returns {undefined}
 * @static
 */
window.focus = function() {};

/**
 * @syntax window.scrollByPages(pages)
 * @param {Number} pages
 * @returns {undefined}
 * @static
 */
window.scrollByPages = function(pages) {};

/**
 * @returns {Number}
 * @static
 */
window.pageXOffset = new Number();

/**
 * @returns {Function}
 * @static
 */
window.onbeforeunload = new Function();

/**
 * @returns {Screen}
 * @static
 */
window.screen = new Screen();

/**
 * @returns {undefined}
 * @static
 */
window.alert = function() {};

/**
 * @syntax var encodedData = window.btoa(stringToEncode);
 * @param {String} stringToEncode
 * @returns {undefined}
 * @static
 */
window.btoa = function(stringToEncode) {};

/**
 * @returns {Components}
 * @static
 */
window.Components = new Components();

/**
 * @returns {Object}
 * @static
 */
window.sidebar = new Object();

/**
 * @syntax window.clearImmediate(immediateID)
 * @param {Number} immediateID
 * @returns {undefined}
 * @static
 */
window.clearImmediate = function(immediateID) {};

/**
 * @returns {Number}
 * @static
 */
window.outerWidth = new Number();

/**
 * @returns {Window}
 * @static
 */
window.content = new Window();

/**
 * @returns {Array}
 * @static
 */
window.frames = new Array();

/**
 * @returns {Number}
 * @static
 */
window.innerWidth = new Number();

/**
 * @returns {Function}
 * @static
 */
window.onmousedown = new Function();

/**
 * @returns {Number}
 * @static
 */
window.pageYOffset = new Number();

/**
 * @syntax target.addEventListener(type, listener[, useCapture])
 * @param {String} type
 * @param {Function} listener
 * @returns {undefined}
 * @static
 */
window.addEventListener = function(type,  listener) {};

/**
 * @returns {Function}
 * @static
 */
window.onunload = new Function();

/**
 * @syntax element.removeEventListener(type, listener, useCapture)
 * @param {String} type
 * @param {Function} listener
 * @param {Boolean} useCapture
 * @returns {undefined}
 * @static
 */
window.removeEventListener = function(type,  listener,  useCapture) {};

/**
 * @returns {Number}
 * @static
 */
window.scrollY = new Number();

/**
 * @returns {Number}
 * @static
 */
window.scrollX = new Number();

/**
 * @syntax escaped = escape(regular);
 * @param {String} regular
 * @returns {String}
 * @static
 */
window.escape = function(regular) {};

/**
 * @returns {document}
 * @static
 */
window.document = new document();

/**
 * @syntax image = new window.Image(width, height)
 * @param {Number} width
 * @param {Number} height
 * @returns {HTMLImageElement}
 * @static
 */
window.Image = function(width,  height) {};

/**
 * @returns {Number}
 * @static
 */
window.length = new Number();

/**
 * @returns {Function}
 * @static
 */
window.onpagehide = new Function();

/**
 * @syntax returnVal = window.showModalDialog(uri[, arguments][, options]);
 * @param {String} uri
 * @returns {Number}
 * @static
 */
window.showModalDialog = function(uri) {};

/**
 * @returns {Boolean}
 * @static
 */
window.closed = new Boolean();

/**
 * @returns {Function}
 * @static
 */
window.onclose = new Function();

/**
 * @syntax window.setCursor()
 * @returns {undefined}
 * @static
 */
window.setCursor = function() {};

/**
 * @returns {Number}
 * @static
 */
window.outerHeight = new Number();

/**
 * @syntax window.back()
 * @returns {undefined}
 * @static
 */
window.back = function() {};

/**
 * @returns {Function}
 * @static
 */
window.onkeydown = new Function();

/**
 * @returns {Function}
 * @static
 */
window.onkeypress = new Function();

/**
 * @returns {Number}
 * @static
 */
window.innerHeight = new Number();

/**
 * @returns {Function}
 * @static
 */
window.onsubmit = new Function();

/**
 * @syntax window.getAttention()
 * @returns {undefined}
 * @static
 */
window.getAttention = function() {};

/**
 * @returns {History}
 * @static
 */
window.history = new History();

/**
 * @returns {XULControllers}
 * @static
 */
window.controllers = new XULControllers();

/**
 * @syntax var timeoutID = window.setTimeout(func, delay, [param1, param2, ...]);<br>var timeoutID = window.setTimeout(code, delay);
 * @param {Function} func
 * @param {String} delay
 * @param {Number} 
 * @returns {Number}
 * @static
 */
window.setTimeout = function(func,  delay) {};

/**
 * @returns {Function}
 * @static
 */
window.onscroll = new Function();

/**
 * @syntax selection = window.getSelection() ;
 * @returns {Selection}
 * @static
 */
window.getSelection = function() {};

/**
 * @returns {Function}
 * @static
 */
window.ondragdrop = new Function();

/**
 * @syntax result = window.prompt(text, value);
 * @param {String} text
 * @param {String} value
 * @returns {String|null}
 * @static
 */
window.prompt = function(text,  value) {};

/**
 * @syntax result = window.confirm(message);
 * @param {String} message
 * @returns {Boolean}
 * @static
 */
window.confirm = function(message) {};

/**
 * @syntax newWindow = openDialog(url, name, features, arg1, arg2, ...)
 * @param {String} url
 * @param {String} name
 * @param {String} features
 * @param {Object} arg1
 * @returns {Window}
 * @static
 */
window.openDialog = function(url,  name,  features,  arg1,  arg2) {};

/**
 * @returns {Object}
 * @static
 */
window.toolbar = new Object();

/**
 * @returns {Object}
 * @static
 */
window.menubar = new Object();

/**
 * @syntax window.close()
 * @returns {undefined}
 * @static
 */
window.close = function() {};

/**
 * @returns {Function}
 * @static
 */
window.onhashchange = new Function();

/**
 * @returns {Object}
 * @static
 */
window.locationbar = new Object();

/**
 * @returns {Function}
 * @static
 */
window.onblur = new Function();

/**
 * @syntax var decodedData = window.atob(encodedData);
 * @param {String} encodedData
 * @returns {String}
 * @static
 */
window.atob = function(encodedData) {};

/**
 * @syntax window.resizeTo(iWidth, iHeight)
 * @param {Number} iWidth
 * @param {Number} iHeight
 * @returns {undefined}
 * @static
 */
window.resizeTo = function(iWidth,  iHeight) {};

/**
 * @returns {String}
 * @static
 */
window.defaultStatus = new String();

/**
 * @syntax window.scrollByLines(lines)
 * @param {Number} lines
 * @returns {undefined}
 * @static
 */
window.scrollByLines = function(lines) {};

/**
 * @syntax mql = window.matchMedia(mediaQueryString)
 * @param {String} mediaQueryString
 * @returns {MediaQueryList}
 * @static
 */
window.matchMedia = function(mediaQueryString) {};

/**
 * @returns {Object}
 * @static
 */
window.scrollbars = new Object();

/**
 * @syntax window.scroll(x-coord, y-coord)
 * @param {Number} xcoord
 * @param {Number} ycoord
 * @returns {undefined}
 * @static
 */
window.scroll = function(xcoord,  ycoord) {};

/**
 * @returns {String}
 * @static
 */
window.status = new String();

/**
 * @returns {Function}
 * @static
 */
window.onmouseout = new Function();

/**
 * @returns {Function}
 * @static
 */
window.onkeyup = new Function();

/**
 * @returns {Function}
 * @static
 */
window.onfocus = new Function();

/**
 * @returns {Function}
 * @static
 */
window.onabort = new Function();

/**
 * @returns {Function}
 * @static
 */
window.onreset = new Function();

/**
 * @returns {Console}
 * @static
 */
window.console = new Console();

/**
 * @returns {Function}
 * @static
 */
window.onselect = new Function();

/**
 * @syntax window.clearTimeout(timeoutID)
 * @param {Number} timeoutID
 * @returns {undefined}
 * @static
 */
window.clearTimeout = function(timeoutID) {};

/**
 * @returns {Number}
 * @static
 */
window.screenTop = new Number();

/**
 * @syntax window.stop()
 * @returns {undefined}
 * @static
 */
window.stop = function() {};

/**
 * @syntax dump(message);
 * @param {String} message
 * @returns {undefined}
 * @static
 */
window.dump = function(message) {};

/**
 * @syntax window.updateCommands("sCommandName")
 * @param {String} "sCommandName"
 * @returns {undefined}
 * @static
 */
window.updateCommands = function(sCommandName) {};

/**
 * @syntax window.blur()
 * @returns {undefined}
 * @static
 */
window.blur = function() {};

/**
 * @syntax window.sizeToContent()
 * @returns {undefined}
 * @static
 */
window.sizeToContent = function() {};

/**
 * @returns {Number}
 * @static
 */
window.screenLeft = new Number();

/**
 * @returns {Function}
 * @static
 */
window.onerror = new Function();

/**
 * @syntax worker = new window.Worker(uri)
 * @param {String} uri
 * @returns {Worker}
 * @static
 */
window.Worker = function(uri) {};

/**
 * @returns {Object}
 * @static
 */
window.performance = new Object();

/**
 * @returns {Object}
 * @static
 */
window.dialogArguments = new Object();

/**
 * @returns {Function}
 * @static
 */
window.onmouseup = new Function();

/**
 * @returns {Function}
 * @static
 */
window.onresize = new Function();

/**
 * @syntax window.clearInterval(intervalID)
 * @param {Number} intervalID
 * @returns {undefined}
 * @static
 */
window.clearInterval = function(intervalID) {};

/**
 * @syntax window.resizeBy(xDelta, yDelta)
 * @param {Number} xDelta
 * @param {Number} yDelta
 * @returns {undefined}
 * @static
 */
window.resizeBy = function(xDelta,  yDelta) {};

/**
 * @returns {Number}
 * @static
 */
window.screenY = new Number();

/**
 * @syntax regular = window.unescape(escaped)
 * @param {String} escaped
 * @returns {String}
 * @static
 */
window.unescape = function(escaped) {};

/**
 * @returns {Number}
 * @static
 */
window.screenX = new Number();

/**
 * @syntax window.moveBy(deltaX, deltaY)
 * @param {Number} deltaX
 * @param {Number} deltaY
 * @returns {undefined}
 * @static
 */
window.moveBy = function(deltaX,  deltaY) {};

/**
 * @returns {Storage}
 * @static
 */
window.sessionStorage = new Storage();

/**
 * @syntax window.find(aString, aCaseSensitive, aBackwards, aWrapAround, aWholeWord, aSearchInFrames, aShowDialog);
 * @param {String} aString
 * @param {Boolean} aCaseSensitive
 * @param {Boolean} aBackwards
 * @param {Boolean} aWrapAround
 * @param {Boolean} aWholeWord
 * @param {Boolean} aSearchInFrames
 * @param {Boolean} aShowDialog
 * @returns {Boolean}
 * @static
 */
window.find = function(aString,  aCaseSensitive,  aBackwards,  aWrapAround,  aWholeWord,  aSearchInFrames,  aShowDialog) {};

/**
 * @syntax var intervalID = window.setInterval(func, delay[, param1, param2, ...]);<br>var intervalID = window.setInterval(code, delay);
 * @param {Function} func
 * @param {String} delay
 * @returns {Number}
 * @static
 */
window.setInterval = function(func,  delay) {};

/**
 * @syntax window.moveTo(x, y)
 * @param {Number} x
 * @param {Number} y
 * @returns {undefined}
 * @static
 */
window.moveTo = function(x,  y) {};

/**
 * @syntax window.scrollBy(X, Y);
 * @param {Number} X
 * @param {Number} Y
 * @returns {undefined}
 * @static
 */
window.scrollBy = function(X,  Y) {};

/**
 * @returns {Function}
 * @static
 */
window.onmousemove = new Function();

/**
 * @returns {Function}
 * @static
 */
window.oncontextmenu = new Function();

/**
 * @syntax window.scrollTo(x-coord, y-coord)
 * @param {Number} xcoord
 * @param {Number} ycoord
 * @returns {undefined}
 * @static
 */
window.scrollTo = function(xcoord,  ycoord) {};

/**
 * @syntax var style = window.getComputedStyle(element[, pseudoElt]);
 * @param {Element} element
 * @returns {CSSStyleDeclaration}
 * @static
 */
window.getComputedStyle = function(element) {};

/**
 * @syntax window.print()
 * @returns {undefined}
 * @static
 */
window.print = function() {};

/**
 * @returns {Function}
 * @static
 */
window.onchange = new Function();

/**
 * @returns {Function}
 * @static
 */
window.onmouseover = new Function();

/**
 * @syntax otherWindow.postMessage(message, targetOrigin);
 * @param {String} message
 * @param {String} targetOrigin
 * @returns {undefined}
 * @static
 */
window.postMessage = function(message,  targetOrigin) {};

/**
 * @returns {Object}
 * @static
 */
window.applicationCache = new Object();

/**
 * @returns {Object}
 * @static
 */
window.statusbar = new Object();

/**
 * @returns {Navigator}
 * @static
 */
window.navigator = new Navigator();

/**
 * @returns {Function}
 * @static
 */
window.onload = new Function();

/**
 * @returns {Function}
 * @static
 */
window.onclick = new Function();

/**
 * Represents the window prototype object.
 * @syntax window.prototype
 * @static
 */
window.prototype;

