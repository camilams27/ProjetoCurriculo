/**
 * @syntax isNaN(number)
 * @param {Number} number
 * @returns {Boolean}
 */
function isNaN(number) {};
