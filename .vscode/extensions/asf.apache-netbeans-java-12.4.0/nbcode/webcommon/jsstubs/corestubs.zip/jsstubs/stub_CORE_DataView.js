/**
 * @syntax new DataView(buffer [, byteOffset [, byteLength]])
 * @param {Object} buffer
 */
function DataView(buffer) {
}
/**
 * @syntax dataview.getUint8(byteOffset)
 * @param {Number} byteOffset
 * @returns {Number}
 */
DataView.prototype.getUint8 = function(byteOffset) {};

/**
 * @syntax dataview.setInt32(byteOffset, value [, littleEndian])
 * @param {Number} byteOffset
 * @param {String} value
 * @param {Boolean} littleEndian
 * @returns {undefined}
 */
DataView.prototype.setInt32 = function(byteOffset, value) {};

/**
 * @syntax dataview.getFloat32(byteOffset [, littleEndian])
 * @param {Number} fbyteOffset
 * @param {Boolean} littleEndian
 * @returns {Number}
 */
DataView.prototype.getFloat32 = function(byteOffset) {};

/**
 * @syntax dataview.getUint16(byteOffset [, littleEndian])
 * @param {Number} byteOffset
 * @param {Boolean} littleEndian
 * @returns {Number}
 */
DataView.prototype.getUint16 = function(byteOffset) {};

/**
 * @syntax dataview.setFloat32(byteOffset, value [, littleEndian])
 * @param {Number} byteOffset
 * @param {String} value
 * @param {Boolean} littleEndian
 * @returns {undefined}
 */
DataView.prototype.setFloat32 = function(byteOffset, value) {};

/**
 * @syntax dataview.getFloat64(byteOffset [, littleEndian])
 * @param {Number} byteOffset
 * @param {Boolean} littleEndian
 * @returns {Number}
 */
DataView.prototype.getFloat64 = function(byteOffset) {};

/**
 * @syntax dataview.getInt8(byteOffset)
 * @param {Number} byteOffset
 * @returns {Number}
 */
DataView.prototype.getInt8 = function(byteOffset) {};

/**
 * @syntax dataview.setInt16(byteOffset, value [, littleEndian])
 * @param {Number} byteOffset
 * @param {String} value
 * @param {Boolean} littleEndian
 * @returns {undefined}
 */
DataView.prototype.setInt16 = function(byteOffset, value) {};

/**
 * @syntax dataview.setInt8(byteOffset, value)
 * @param {Number} byteOffset
 * @param {String} value
 * @returns {undefined}
 */
DataView.prototype.setInt8 = function(byteOffset, value) {};

/**
 * @since ECMAScript6
 * @syntax dataview.byteOffset
 * @returns {Number}
 */
DataView.prototype.byteOffset = new Number();

/**
 * @syntax dataview.getInt32(byteOffset [, littleEndian])
 * @param {Number} byteOffset
 * @param {Boolean} littleEndian
 * @returns {Number}
 */
DataView.prototype.getInt32 = function(byteOffset) {};

/**
 * @syntax dataview.setFloat64(byteOffset, value [, littleEndian])
 * @param {Number} byteOffset
 * @param {String} value
 * @param {Boolean} littleEndian
 * @returns {undefined}
 */
DataView.prototype.setFloat64 = function(byteOffset, value) {};

/**
 * @syntax dataview.getInt16(byteOffset [, littleEndian])
 * @param {Number} byteOffset
 * @param {Boolean} littleEndian
 * @returns {Number}
 */
DataView.prototype.getInt16 = function(byteOffset) {};

/**
 * @syntax dataview.setUint8(byteOffset, value)
 * @param {Number} byteOffset
 * @param {String} value
 * @returns {undefined}
 */
DataView.prototype.setUint8 = function(byteOffset, value) {};

/**
 * @syntax dataview.getUint32(byteOffset [, littleEndian])
 * @param {Number} byteOffset
 * @param {Boolean} littleEndian
 * @returns {Number}
 */
DataView.prototype.getUint32 = function(byteOffset) {};

/**
 * @syntax dataview.setUint32(byteOffset, value [, littleEndian])
 * @param {Number} byteOffset
 * @param {String} value
 * @param {Boolean} littleEndian
 * @returns {undefined}
 */
DataView.prototype.setUint32 = function(byteOffset, value) {};

/**
 * @syntax dataview.setUint16(byteOffset, value [, littleEndian])
 * @param {Number} byteOffset
 * @param {String} value
 * @param {Boolean} littleEndian
 * @returns {undefined}
 */
DataView.prototype.setUint16 = function(byteOffset, value) {};

/**
 * @since ECMAScript6
 * @syntax dataview.buffer
 * @returns {Object}
 */
DataView.prototype.buffer = new Object();

/**
 * @since ECMAScript6
 * @syntax dataview.byteLength
 * @returns {Number}
 */
DataView.prototype.byteLength = new Number();

/**
 * Represents the DataView prototype object.
 * @syntax DataView.prototype
 * @static
 */
DataView.prototype;

