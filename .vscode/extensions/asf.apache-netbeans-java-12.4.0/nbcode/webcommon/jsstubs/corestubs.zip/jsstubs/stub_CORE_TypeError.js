/**
 * @syntax new TypeError([message[, [, ]]])
 * @returns {Error}
 */
function TypeError() {
}
/**
 * @returns {String}
 */
TypeError.prototype.name = new String();

/**
 * @returns {String}
 */
TypeError.prototype.message = new String();

/**
 * @syntax e.toString()
 * @returns {String}
 */
TypeError.prototype.toString = function() {};

/**
 * Represents the TypeError prototype object.
 * @syntax TypeError.prototype
 * @static
 */
TypeError.prototype;

