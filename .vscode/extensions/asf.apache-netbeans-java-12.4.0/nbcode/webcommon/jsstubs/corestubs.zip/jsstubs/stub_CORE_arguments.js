/**
 * @syntax arguments
 */
function arguments() {
}
/**
 * Represents the arguments prototype object.
 * @syntax arguments.prototype
 * @static
 */
arguments.prototype;

