/**
 * @since ECMAScript6
 * @syntax new Map([iterable])
 */
function Map() {
}
/**
 * @since ECMAScript6
 * @returns {Number}
 */
Map.prototype.size = new Number();

/**
 * @since ECMAScript6
 * @syntax myMap.entries()
 * @returns {Array}
 */
Map.prototype.entries = function() {};

/**
 * @since ECMAScript6
 * @syntax myMap.values()
 * @returns {Array}
 */
Map.prototype.values = function() {};

/**
 * @since ECMAScript6
 * @syntax myMap.forEach(callback[, thisArg])
 * @param {Function} callback
 * @param {String} thisArg
 * @returns {undefined}
 */
Map.prototype.forEach = function(callback) {};

/**
 * @since ECMAScript6
 * @syntax myMap.get(key)
 * @param {Object} key
 * @returns {Object}
 */
Map.prototype.get = function(key) {};

/**
 * @since ECMAScript6
 * @syntax myMap.keys()
 * @returns {Array}
 */
Map.prototype.keys = function() {};

/**
 * @since ECMAScript6
 * @syntax myMap.delete(key)
 * @param {Object} key
 * @returns {Boolean}
 */
Map.prototype.delete = function(key) {};

/**
 * @since ECMAScript6
 * @syntax myMap.set(key, value)
 * @param {Object} key
 * @param {Object} value
 * @returns {Object}
 */
Map.prototype.set = function(key, value) {};

/**
 * @since ECMAScript6
 * @syntax myMap.has(key)
 * @param {Object} key
 * @returns {Boolean}
 */
Map.prototype.has = function(key) {};

/**
 * @since ECMAScript6
 * @syntax myMap.clear()
 * @returns {undefined}
 */
Map.prototype.clear = function() {};

/**
 * Represents the Map prototype object.
 * @syntax Map.prototype
 * @static
 */
Map.prototype;

