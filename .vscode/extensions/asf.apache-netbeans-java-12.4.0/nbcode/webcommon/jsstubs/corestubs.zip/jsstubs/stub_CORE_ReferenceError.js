/**
 * @syntax new ReferenceError([message[, [, ]]])
 * @returns {Error}
 */
function ReferenceError() {
}
/**
 * @returns {String}
 */
ReferenceError.prototype.name = new String();

/**
 * @returns {String}
 */
ReferenceError.prototype.message = new String();

/**
 * @syntax e.toString()
 * @returns {String}
 */
ReferenceError.prototype.toString = function() {};

/**
 * Represents the ReferenceError prototype object.
 * @syntax ReferenceError.prototype
 * @static
 */
ReferenceError.prototype;

