/**
 * @syntax new URIError([message[, [, ]]])
 * @returns {Error}
 */
function URIError() {
}
/**
 * @returns {String}
 */
URIError.prototype.name = new String();

/**
 * @returns {String}
 */
URIError.prototype.message = new String();

/**
 * @syntax e.toString()
 * @returns {String}
 */
URIError.prototype.toString = function() {};

/**
 * Represents the URIError prototype object.
 * @syntax URIError.prototype
 * @static
 */
URIError.prototype;

