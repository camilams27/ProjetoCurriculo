/**
 * @syntax new Error([message[, [, ]]])
 * @returns {Error}
 */
function Error() {
}
/**
 * @returns {String}
 */
Error.prototype.name = new String();

/**
 * @returns {String}
 */
Error.prototype.message = new String();

/**
 * @syntax e.toString()
 * @returns {String}
 */
Error.prototype.toString = function() {};

/**
 * Represents the Error prototype object.
 * @syntax Error.prototype
 * @static
 */
Error.prototype;

