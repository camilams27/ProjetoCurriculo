/**
 * @since ECMAScript6
 * @syntax new Set([iterable])
 */
function Set() {
}
/**
 * @since ECMAScript6
 * @returns {Number}
 */
Set.prototype.size = new Number();

/**
 * @since ECMAScript6
 * @syntax mySet.has(value)
 * @param {Object} value
 * @returns {Boolean}
 */
Set.prototype.has = function(value) {};

/**
 * @since ECMAScript6
 * @syntax mySet.forEach(callback[, thisArg])
 * @param {Function} callback
 * @param {String} thisArg
 * @returns {undefined}
 */
Set.prototype.forEach = function(callback) {};

/**
 * @since ECMAScript6
 * @syntax mySet.clear()
 * @returns {undefined}
 */
Set.prototype.clear = function() {};

/**
 * @since ECMAScript6
 * @syntax mySet.add(value)
 * @param {Object} value
 * @returns {Object}
 */
Set.prototype.add = function(value) {};

/**
 * @since ECMAScript6
 * @syntax mySet.values() mySet.keys()
 * @returns {Array}
 */
Set.prototype.values = function() {};

/**
 * @since ECMAScript6
 * @syntax mySet.entries()
 * @returns {Array}
 */
Set.prototype.entries = function() {};

/**
 * @since ECMAScript6
 * @syntax mySet.delete(value)
 * @param {Object} value
 * @returns {Boolean}
 */
Set.prototype.delete = function(value) {};

/**
 * Represents the Set prototype object.
 * @syntax Set.prototype
 * @static
 */
Set.prototype;

