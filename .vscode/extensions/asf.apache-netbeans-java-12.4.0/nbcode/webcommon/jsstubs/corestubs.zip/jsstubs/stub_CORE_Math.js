/**
 * @returns {Math}
 */
var Math = {
}
/**
 * @returns {Number}
 * @static
 */
Math.SQRT2 = new Number();

/**
 * @since ECMAScript6
 * @syntax Math.acosh(x)
 * @param {Number} x
 * @returns {Number}
 * @static
 */
Math.acosh = function(x) {};

/**
 * @syntax Math.exp(x)
 * @param {Number} x
 * @returns {Number}
 * @static
 */
Math.exp = function(x) {};

/**
 * @syntax Math.sqrt(x)
 * @param {Number} x
 * @returns {Number}
 * @static
 */
Math.sqrt = function(x) {};

/**
 * @syntax Math.log(x)
 * @param {Number} x
 * @returns {Number}
 * @static
 */
Math.log = function(x) {};

/**
 * @since ECMAScript6
 * @syntax Math.trunc(x)
 * @param {Number} x
 * @returns {Number}
 * @static
 */
Math.trunc = function(x) {};

/**
 * @syntax Math.min([value1[, value2[, ...]]])
 * @returns {Number}
 * @static
 */
Math.min = function() {};

/**
 * @syntax Math.sin(x)
 * @param {Number} x
 * @returns {Number}
 * @static
 */
Math.sin = function(x) {};

/**
 * @returns {Number}
 * @static
 */
Math.LOG10E = new Number();

/**
 * @returns {Number}
 * @static
 */
Math.E = new Number();

/**
 * @since ECMAScript6
 * @syntax Math.clz32(x)
 * @param {Number} x
 * @returns {Number}
 * @static
 */
Math.clz32 = function(x) {};

/**
 * @returns {Number}
 * @static
 */
Math.LN2 = new Number();

/**
 * @syntax Math.atan2(y, x)
 * @param {Number} y
 * @param {Number} x
 * @returns {Number}
 * @static
 */
Math.atan2 = function(y, x) {};

/**
 * @returns {Number}
 * @static
 */
Math.SQRT1_2 = new Number();

/**
 * @returns {Number}
 * @static
 */
Math.LOG2E = new Number();

/**
 * @syntax Math.asin(x)
 * @param {Number} x
 * @returns {Number}
 * @static
 */
Math.asin = function(x) {};

/**
 * @since ECMAScript6
 * @syntax Math.atanh(x)
 * @param {Number} x
 * @returns {Number}
 * @static
 */
Math.atanh = function(x) {};

/**
 * @since ECMAScript6
 * @syntax Math.tanh(x)
 * @param {Number} x
 * @returns {Number}
 * @static
 */
Math.tanh = function(x) {};

/**
 * @syntax Math.max([value1[, value2[, ...]]])
 * @returns {Number}
 * @static
 */
Math.max = function() {};

/**
 * @since ECMAScript6
 * @syntax Math.hypot([value1[, value2[, ...]]])
 * @returns {Number}
 * @static
 */
Math.hypot = function() {};

/**
 * @since ECMAScript6
 * @syntax Math.imul(a, b)
 * @param {Number} a
 * @param {Number} b
 * @returns {Number}
 * @static
 */
Math.imul = function(a, b) {};

/**
 * @syntax Math.pow(base, exponent)
 * @param {Number} base
 * @param {Number} exponent
 * @returns {Number}
 * @static
 */
Math.pow = function(base, exponent) {};

/**
 * @syntax Math.random()
 * @returns {Number}
 * @static
 */
Math.random = function() {};

/**
 * @since ECMAScript6
 * @syntax Math.expm1(x)
 * @param {Number} x
 * @returns {Number}
 * @static
 */
Math.expm1 = function(x) {};

/**
 * @syntax Math.ceil(x)
 * @param {Number} x
 * @returns {Number}
 * @static
 */
Math.ceil = function(x) {};

/**
 * @since ECMAScript6
 * @syntax Math.sinh(x)
 * @param {Number} x
 * @returns {Number}
 * @static
 */
Math.sinh = function(x) {};

/**
 * @returns {Number}
 * @static
 */
Math.PI = new Number();

/**
 * @syntax Math.atan(x)
 * @param {Number} x
 * @returns {Number}
 * @static
 */
Math.atan = function(x) {};

/**
 * @since ECMAScript6
 * @syntax Math.fround(x)
 * @param {Number} x
 * @returns {Number}
 * @static
 */
Math.fround = function(x) {};

/**
 * @since ECMAScript6
 * @syntax Math.sign(x)
 * @param {Number} x
 * @returns {Number}
 * @static
 */
Math.sign = function(x) {};

/**
 * @syntax Math.acos(x)
 * @param {Number} x
 * @returns {Number}
 * @static
 */
Math.acos = function(x) {};

/**
 * @since ECMAScript6
 * @syntax Math.cbrt(x)
 * @param {Number} x
 * @returns {Number}
 * @static
 */
Math.cbrt = function(x) {};

/**
 * @since ECMAScript6
 * @syntax Math.log10(x)
 * @param {Number} x
 * @returns {Number}
 * @static
 */
Math.log10 = function(x) {};

/**
 * @since ECMAScript6
 * @syntax Math.log1p(x)
 * @param {Number} x
 * @returns {Number}
 * @static
 */
Math.log1p = function(x) {};

/**
 * @since ECMAScript6
 * @syntax Math.cosh(x)
 * @param {Number} x
 * @returns {Number}
 * @static
 */
Math.cosh = function(x) {};

/**
 * @syntax Math.abs(x)
 * @param {Number} x
 * @returns {Number}
 * @static
 */
Math.abs = function(x) {};

/**
 * @syntax Math.tan(x)
 * @param {Number} x
 * @returns {Number}
 * @static
 */
Math.tan = function(x) {};

/**
 * @returns {Number}
 * @static
 */
Math.LN10 = new Number();

/**
 * @since ECMAScript6
 * @syntax Math.asinh(x)
 * @param {Number} x
 * @returns {Number}
 * @static
 */
Math.asinh = function(x) {};

/**
 * @syntax Math.cos(x)
 * @param {Number} x
 * @returns {Number}
 * @static
 */
Math.cos = function(x) {};

/**
 * @since ECMAScript6
 * @syntax Math.log2(x)
 * @param {Number} x
 * @returns {Number}
 * @static
 */
Math.log2 = function(x) {};

/**
 * @syntax Math.round(x)
 * @param {Number} x
 * @returns {Number}
 * @static
 */
Math.round = function(x) {};

/**
 * @syntax Math.floor(x)
 * @param {Number} x
 * @returns {Number}
 * @static
 */
Math.floor = function(x) {};

/**
 * Represents the Math prototype object.
 * @syntax Math.prototype
 * @static
 */
Math.prototype;

