/**
 * @syntax parseInt(string,radix)
 * @param {String} string
 * @param {String} radix
 * @returns {Number}
 */
function parseInt(string, radix) {};
