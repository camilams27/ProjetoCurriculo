/**
 * @syntax /pattern/flags new RegExp(pattern[, flags])
 * @param {String} pattern
 * @returns {RegExp}
 */
function RegExp(pattern) {
}
/**
 * @returns {String}
 */
RegExp.prototype.source = new String();

/**
 * @since ECMAScript6
 * @deprecated
 * @syntax regexObj.compile(pattern, flags)
 * @param {String} pattern
 * @param {String} flags
 */
RegExp.prototype.compile = function(pattern, flags) {};

/**
 * @since ECMAScript6
 * @returns {Boolean}
 */
RegExp.prototype.unicode = new Boolean();

/**
 * @since ECMAScript6
 * @returns {Boolean}
 */
RegExp.prototype.sticky = new Boolean();

/**
 * @syntax regExpObj.lastIndex
 * @returns {Number}
 * @static
 */
RegExp.lastIndex = new Number();

/**
 * @syntax regExp.compile(regexp, modifier)
 * @param {RegExp} regexp
 * @param {String} modifier
 * @returns {RegExp}
 */
RegExp.prototype.compile = function(regexp, modifier) {};

/**
 * @since ECMAScript6
 * @returns {String}
 */
RegExp.prototype.flags = new String();

/**
 * @syntax regexObj.test(str)
 * @param {String} str
 * @returns {Boolean}
 */
RegExp.prototype.test = function(str) {};

/**
 * @returns {Boolean}
 */
RegExp.prototype.global = new Boolean();

/**
 * @returns {Boolean}
 */
RegExp.prototype.multiline = new Boolean();

/**
 * @returns {Boolean}
 */
RegExp.prototype.ignoreCase = new Boolean();

/**
 * @syntax regexObj.exec(str)
 * @param {String} str
 * @returns {Array}
 */
RegExp.prototype.exec = function(str) {};

/**
 * @syntax regexObj.toString()
 * @returns {String}
 */
RegExp.prototype.toString = function() {};

/**
 * Represents the RegExp prototype object.
 * @syntax RegExp.prototype
 * @static
 */
RegExp.prototype;

