/**
 * @syntax undefined
 * @returns {undefined}
 */
function undefined() {
}
/**
 * Represents the undefined prototype object.
 * @syntax undefined.prototype
 * @static
 */
undefined.prototype;

