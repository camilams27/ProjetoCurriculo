/**
 * @syntax new ArrayBuffer(length)
 * @param {Number} length
 * @returns {ArrayBuffer}
 */
function ArrayBuffer(length) {
}
/**
 * @syntax arraybuffer.byteLength
 * @returns {Number}
 */
ArrayBuffer.prototype.byteLength = new Number();

/**
 * @syntax ArrayBuffer.isView(arg)
 * @param {String} arg
 * @returns {Boolean}
 * @static
 */
ArrayBuffer.isView = function(arg) {};

/**
 * @syntax arraybuffer.slice(begin[, end])
 * @param {Number} begin
 * @returns {Object}
 */
ArrayBuffer.prototype.slice = function(begin) {};

/**
 * Represents the ArrayBuffer prototype object.
 * @syntax ArrayBuffer.prototype
 * @static
 */
ArrayBuffer.prototype;

