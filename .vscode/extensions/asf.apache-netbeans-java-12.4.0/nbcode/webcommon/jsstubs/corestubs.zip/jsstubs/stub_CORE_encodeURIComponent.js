/**
 * @syntax encodeURIComponent(uriComponent)
 * @param {String} uriComponent
 * @returns {String}
 */
function encodeURIComponent(uriComponent) {};
