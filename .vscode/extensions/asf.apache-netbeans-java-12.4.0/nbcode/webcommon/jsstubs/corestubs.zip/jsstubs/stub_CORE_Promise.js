/**
 * @since ECMAScript6
 * @syntax new Promise(executor)
 * @param {Function} executor
 */
function Promise(executor) {
}
/**
 * @since ECMAScript6
 * @syntax p.then(onFulfilled, onRejected) p.then(function(value) { // fulfillment }, function(reason) { // rejection })
 * @param {String} onFulfilled
 * @param {String} onRejected
 * @returns {Promise}
 */
Promise.prototype.then = function(onFulfilled, onRejected) {};

/**
 * @since ECMAScript6
 * @syntax Promise.resolve(value) Promise.resolve(promise) Promise.resolve(thenable)
 * @param {String} value
 * @returns {Promise}
 * @static
 */
Promise.resolve = function(value) {};

/**
 * @since ECMAScript6
 * @syntax Promise.race(iterable)
 * @param {Object} iterable
 * @returns {Promise}
 * @static
 */
Promise.race = function(iterable) {};

/**
 * @since ECMAScript6
 * @syntax Promise.reject(reason)
 * @param {String} reason
 * @returns {Promise}
 * @static
 */
Promise.reject = function(reason) {};

/**
 * @since ECMAScript6
 * @syntax p.catch(onRejected) p.catch(function(reason) { // rejection })
 * @param {String} onRejected
 * @returns {Promise}
 */
Promise.prototype.catch = function(onRejected) {};

/**
 * @since ECMAScript6
 * @syntax Promise.all(iterable)
 * @param {Object} iterable
 * @returns {Promise}
 * @static
 */
Promise.all = function(iterable) {};

/**
 * Represents the Promise prototype object.
 * @syntax Promise.prototype
 * @static
 */
Promise.prototype;

