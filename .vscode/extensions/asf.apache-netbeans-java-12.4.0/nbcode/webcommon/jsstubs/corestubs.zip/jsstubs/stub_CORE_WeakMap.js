/**
 * @since ECMAScript6
 * @syntax new WeakMap([iterable])
 */
function WeakMap() {
}
/**
 * @since ECMAScript6
 * @syntax wm.get(key)
 * @param {Object} key
 * @returns {Object}
 */
WeakMap.prototype.get = function(key) {};

/**
 * @since ECMAScript6
 * @syntax wm.set(key, value)
 * @param {Object} key
 * @param {Object} value
 * @returns {Object}
 */
WeakMap.prototype.set = function(key, value) {};

/**
 * @since ECMAScript6
 * @syntax wm.has(key)
 * @param {Object} key
 * @returns {Boolean}
 */
WeakMap.prototype.has = function(key) {};

/**
 * @since ECMAScript6
 * @syntax wm.delete(key)
 * @param {Object} key
 * @returns {Boolean}
 */
WeakMap.prototype.delete = function(key) {};

/**
 * Represents the WeakMap prototype object.
 * @syntax WeakMap.prototype
 * @static
 */
WeakMap.prototype;

