/**
 * @syntax new EvalError([message[, [, ]]])
 * @returns {Error}
 */
function EvalError() {
}
/**
 * @returns {String}
 */
EvalError.prototype.name = new String();

/**
 * @returns {String}
 */
EvalError.prototype.message = new String();

/**
 * @syntax e.toString()
 * @returns {String}
 */
EvalError.prototype.toString = function() {};

/**
 * Represents the EvalError prototype object.
 * @syntax EvalError.prototype
 * @static
 */
EvalError.prototype;

