/**
 * @syntax new RangeError([message[, [, ]]])
 * @returns {Error}
 */
function RangeError() {
}
/**
 * @returns {String}
 */
RangeError.prototype.name = new String();

/**
 * @returns {String}
 */
RangeError.prototype.message = new String();

/**
 * @syntax e.toString()
 * @returns {String}
 */
RangeError.prototype.toString = function() {};

/**
 * Represents the RangeError prototype object.
 * @syntax RangeError.prototype
 * @static
 */
RangeError.prototype;

