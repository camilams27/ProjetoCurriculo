/**
 * @syntax new Float32Array(length) new Float32Array(typedArray) new Float32Array(object) new Float32Array(buffer [, byteOffset [, length]])
 * @returns {Array}
 */
function Float32Array(length) {
}
/**
 * @since ECMAScript6
 * @syntax TypedArray.name
 * @returns {String}
 * @static
 */
Float32Array.name = new String();

/**
 * @since ECMAScript6
 * @syntax typedarray.reduceRight(callback[, initialValue])
 * @param {Function} callback
 * @param {Object} initialValue
 * @returns {Object}
 */
Float32Array.prototype.reduceRight = function(callback) {};

/**
 * @since ECMAScript6
 * @syntax typedarray.slice([begin[, end]])
 * @param {Number} begin
 * @param {Number} end
 * @returns {Array}
 */
Float32Array.prototype.slice = function() {};

/**
 * @since ECMAScript6
 * @syntax typedarray.every(callback[, thisArg])
 * @param {Function} callback
 * @param {String} thisArg
 * @returns {Boolean}
 */
Float32Array.prototype.every = function(callback) {};

/**
 * @since ECMAScript6
 * @syntax typedarray.join([separator = ','])
 * @param {String} separator
 * @returns {String}
 */
Float32Array.prototype.join = function() {};

/**
 * @syntax typedarray.subarray([begin [,end]])
 * @param {Number} beginOptional
 * @param {Number} endOptional
 * @returns {Array}
 */
Float32Array.prototype.subarray = function() {};

/**
 * @since ECMAScript6
 * @syntax typedarray.reverse()
 * @returns {Array}
 */
Float32Array.prototype.reverse = function() {};

/**
 * @since ECMAScript6
 * @syntax TypedArray.from(source[, mapFn[, thisArg]]) where TypedArray is one of: Int8Array Uint8Array Uint8ClampedArray Int16Array Uint16Array Int32Array Uint32Array Float32Array Float64Array
 * @param {Object} source
 * @param {Array} mapFn
 * @param {String} thisArg
 * @returns {Array}
 * @static
 */
Float32Array.from = function(source) {};

/**
 * @since ECMAScript6
 * @syntax typedarray.lastIndexOf(searchElement[, fromIndex = typedarray.length])
 * @param {Object} searchElement
 * @param {Number} fromIndex
 * @returns {Number}
 */
Float32Array.prototype.lastIndexOf = function(searchElement) {};

/**
 * @since ECMAScript6
 * @syntax typedarray.filter(callback[, thisArg])
 * @param {Function} callback
 * @param {String} thisArgOptional
 * @returns {Array}
 */
Float32Array.prototype.filter = function(callback) {};

/**
 * @since ECMAScript6
 * @syntax typedarray.reduce(callback[, initialValue])
 * @param {Function} callback
 * @param {Object} initialValue
 * @returns {Object}
 */
Float32Array.prototype.reduce = function(callback) {};

/**
 * @since ECMAScript6
 * @syntax arr.values()
 * @returns {Array}
 */
Float32Array.prototype.values = function() {};

/**
 * @since ECMAScript6
 * @syntax typedarray.fill(value[, start = 0[, end = this.length]])
 * @param {Array} value
 * @param {Number} start
 * @param {Number} end
 * @returns {undefined}
 */
Float32Array.prototype.fill = function(value) {};

/**
 * @since ECMAScript6
 * @syntax typedarray.indexOf(searchElement[, fromIndex = 0])
 * @param {Array} searchElement
 * @param {Number} fromIndex
 * @returns {Number}
 */
Float32Array.prototype.indexOf = function(searchElement) {};

/**
 * @since ECMAScript6
 * @syntax typedarray.includes(searchElement[, fromIndex])
 * @param {String} searchElement
 * @param {Number} fromIndex
 * @returns {Boolean}
 */
Float32Array.prototype.includes = function(searchElement) {};

/**
 * @since ECMAScript6
 * @syntax typedarray.byteLength
 * @returns {Number}
 */
Float32Array.prototype.byteLength = new Number();

/**
 * @since ECMAScript6
 * @syntax typedarray.find(callback[, thisArg])
 * @param {Function} callback
 * @param {Object} thisArg
 * @returns {Object}
 */
Float32Array.prototype.find = function(callback) {};

/**
 * @since ECMAScript6
 * @syntax typedarray.map(callback[, thisArg])
 * @param {Function} callback
 * @param {String} thisArg
 * @returns {Array}
 */
Float32Array.prototype.map = function(callback) {};

/**
 * @since ECMAScript6
 * @syntax TypedArray.of(element0[, element1[, ...[, elementN]]]) where TypedArray is one of: Int8Array Uint8Array Uint8ClampedArray Int16Array Uint16Array Int32Array Uint32Array Float32Array Float64Array
 * @param {Array} elementN
 * @returns {Array}
 * @static
 */
Float32Array.of = function(element0) {};

/**
 * @since ECMAScript6
 * @syntax typedarray.some(callback[, thisArg])
 * @param {Function} callback
 * @param {String} thisArg
 * @returns {Boolean}
 */
Float32Array.prototype.some = function(callback) {};

/**
 * @since ECMAScript6
 * @syntax typedarray.forEach(callback[, thisArg])
 * @param {Function} callback
 * @param {String} thisArg
 * @returns {undefined}
 */
Float32Array.prototype.forEach = function(callback) {};

/**
 * @since ECMAScript6
 * @syntax typedarray.copyWithin(target, start[, end = this.length])
 * @param {String} target
 * @param {Number} start
 * @param {Number} endOptional
 * @returns {undefined}
 */
Float32Array.prototype.copyWithin = function(target, start) {};

/**
 * @since ECMAScript6
 * @syntax arr.entries()
 * @returns {Array}
 */
Float32Array.prototype.entries = function() {};

/**
 * @since ECMAScript6
 * @syntax typedArray.buffer
 * @returns {Object}
 */
Float32Array.prototype.buffer = new Object();

/**
 * @since ECMAScript6
 * @syntax typedarray.byteOffset
 * @returns {Number}
 */
Float32Array.prototype.byteOffset = new Number();

/**
 * @since ECMAScript6
 * @syntax typedarray.length
 * @returns {Number}
 */
Float32Array.prototype.length = new Number();

/**
 * @since ECMAScript6
 * @syntax arr.keys()
 * @returns {Array}
 */
Float32Array.prototype.keys = function() {};

/**
 * @syntax TypedArray.BYTES_PER_ELEMENT
 * @returns {Number}
 * @static
 */
Float32Array.BYTES_PER_ELEMENT = new Number();

/**
 * @since ECMAScript6
 * @syntax typedarray.findIndex(callback[, thisArg])
 * @param {Function} callback
 * @param {Object} thisArg
 * @returns {Number}
 */
Float32Array.prototype.findIndex = function(callback) {};

/**
 * @since ECMAScript6
 * @syntax typedarray.sort([compareFunction])
 * @param {String} compareFunction
 * @returns {Array}
 */
Float32Array.prototype.sort = function() {};

/**
 * @syntax typedarr.set(array [,offset]) typedarr.set(typedarray [,offset])
 * @param {Array} array
 * @param {Object} typedarray
 * @param {Array} offsetOptional
 * @returns {undefined}
 */
Float32Array.prototype.set = function(array) {};

/**
 * Represents the Float32Array prototype object.
 * @syntax Float32Array.prototype
 * @static
 */
Float32Array.prototype;

