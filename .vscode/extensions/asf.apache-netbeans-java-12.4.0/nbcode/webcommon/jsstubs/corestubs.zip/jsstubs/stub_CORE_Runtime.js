/**
 * @syntax RuntimeSemantics:PerformEval(x,evalRealm,strictCaller,direct)
 * @param {String} x
 * @param {String} evalRealm
 * @param {String} strictCaller
 * @param {String} direct
 * @returns {String}
 */
function Runtime(x, evalRealm, strictCaller, direct) {};
