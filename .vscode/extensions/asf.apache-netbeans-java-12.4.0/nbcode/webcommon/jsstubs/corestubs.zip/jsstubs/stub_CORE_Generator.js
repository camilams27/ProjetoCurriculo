/**
 * @since ECMAScript6
 * @syntax function* gen() { yield 1 yield 2 yield 3 } var g = gen() // "Generator { }"
 */
function Generator() {
}
/**
 * @since ECMAScript6
 * @syntax gen.throw(exception)
 * @param {String} exception
 * @returns {Object}
 */
Generator.prototype.throw = function(exception) {};

/**
 * @since ECMAScript6
 * @syntax gen.next(value)
 * @param {String} value
 * @returns {Object}
 */
Generator.prototype.next = function(value) {};

/**
 * @since ECMAScript6
 * @syntax gen.return(value)
 * @param {String} value
 * @returns {undefined}
 */
Generator.prototype.return = function(value) {};

/**
 * Represents the Generator prototype object.
 * @syntax Generator.prototype
 * @static
 */
Generator.prototype;

