/**
 * @since ECMAScript6
 * @syntax new GeneratorFunction ([arg1[, arg2[, ...argN]],] functionBody)
 */
function GeneratorFunction() {
}
/**
 * Represents the GeneratorFunction prototype object.
 * @syntax GeneratorFunction.prototype
 * @static
 */
GeneratorFunction.prototype;

