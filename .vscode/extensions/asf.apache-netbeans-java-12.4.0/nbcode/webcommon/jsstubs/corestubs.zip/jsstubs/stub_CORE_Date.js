/**
 * @syntax new Date() new Date(value) new Date(dateString) new Date(year, month[, day[, hour[, minutes[, seconds[, milliseconds]]]]])
 * @returns {Date}
 */
function Date() {
}
/**
 * @syntax dateObj.toTimeString()
 * @returns {String}
 */
Date.prototype.toTimeString = function() {};

/**
 * @syntax Date.parse(dateString)
 * @param {String} dateString
 * @returns {Number}
 * @static
 */
Date.parse = function(dateString) {};

/**
 * @deprecated
 * @syntax dateObj.getYear()
 * @returns {Number}
 */
Date.prototype.getYear = function() {};

/**
 * @syntax dateObj.getFullYear()
 * @returns {Number}
 */
Date.prototype.getFullYear = function() {};

/**
 * @syntax dateObj.toUTCString()
 * @returns {String}
 */
Date.prototype.toUTCString = function() {};

/**
 * @syntax dateObj.toString()
 * @returns {String}
 */
Date.prototype.toString = function() {};

/**
 * @syntax dateObj.getUTCDay()
 * @returns {Number}
 */
Date.prototype.getUTCDay = function() {};

/**
 * @syntax dateObj.toLocaleDateString([locales [, options]])
 * @param {Array} locales
 * @param {String} options
 * @returns {String}
 */
Date.prototype.toLocaleDateString = function() {};

/**
 * @syntax dateObj.setHours(hoursValue[, minutesValue[, secondsValue[, msValue]]])
 * @param {Number} hoursValue
 * @param {Number} minutesValue
 * @param {Number} secondsValue
 * @param {Number} msValue
 * @returns {Number}
 */
Date.prototype.setHours = function(hoursValue) {};

/**
 * @deprecated
 * @syntax dateObj.setYear(yearValue)
 * @param {Number} yearValue
 * @returns {Number}
 */
Date.prototype.setYear = function(yearValue) {};

/**
 * @syntax dateObj.setUTCFullYear(yearValue[, monthValue[, dayValue]])
 * @param {Number} yearValue
 * @param {Number} monthValue
 * @param {Number} dayValue
 * @returns {Number}
 */
Date.prototype.setUTCFullYear = function(yearValue) {};

/**
 * @syntax dateObj.getTimezoneOffset()
 * @returns {Number}
 */
Date.prototype.getTimezoneOffset = function() {};

/**
 * @syntax dateObj.setFullYear(yearValue[, monthValue[, dayValue]])
 * @param {Number} yearValue
 * @param {Number} monthValue
 * @param {Number} dayValue
 * @returns {Number}
 */
Date.prototype.setFullYear = function(yearValue) {};

/**
 * @syntax dateObj.setUTCMinutes(minutesValue[, secondsValue[, msValue]])
 * @param {Number} minutesValue
 * @param {Number} secondsValue
 * @param {Number} msValue
 * @returns {Number}
 */
Date.prototype.setUTCMinutes = function(minutesValue) {};

/**
 * @syntax dateObj.toLocaleString([locales[, options]])
 * @param {Array} locales
 * @param {String} options
 * @returns {String}
 */
Date.prototype.toLocaleString = function() {};

/**
 * @syntax dateObj.getUTCSeconds()
 * @returns {Number}
 */
Date.prototype.getUTCSeconds = function() {};

/**
 * @syntax dateObj.setMinutes(minutesValue[, secondsValue[, msValue]])
 * @param {Number} minutesValue
 * @param {Number} secondsValue
 * @param {Number} msValue
 * @returns {Number}
 */
Date.prototype.setMinutes = function(minutesValue) {};

/**
 * @syntax dateObj.getTime()
 * @returns {Number}
 */
Date.prototype.getTime = function() {};

/**
 * @syntax dateObj.toDateString()
 * @returns {String}
 */
Date.prototype.toDateString = function() {};

/**
 * @syntax dateObj.getDay()
 * @returns {Number}
 */
Date.prototype.getDay = function() {};

/**
 * @syntax dateObj.toLocaleTimeString([locales[, options]])
 * @param {Array} locales
 * @param {String} options
 * @returns {String}
 */
Date.prototype.toLocaleTimeString = function() {};

/**
 * @syntax dateObj.valueOf()
 * @returns {Number}
 */
Date.prototype.valueOf = function() {};

/**
 * @syntax var timeInMs = Date.now()
 * @returns {Number}
 * @static
 */
Date.now = function() {};

/**
 * @syntax dateObj.getMonth()
 * @returns {Number}
 */
Date.prototype.getMonth = function() {};

/**
 * @syntax dateObj.setUTCHours(hoursValue[, minutesValue[, secondsValue[, msValue]]])
 * @param {Number} hoursValue
 * @param {Number} minutesValue
 * @param {Number} secondsValue
 * @param {Number} msValue
 * @returns {Number}
 */
Date.prototype.setUTCHours = function(hoursValue) {};

/**
 * @syntax dateObj.getDate()
 * @returns {Number}
 */
Date.prototype.getDate = function() {};

/**
 * @syntax dateObj.setMilliseconds(millisecondsValue)
 * @param {Number} millisecondsValue
 * @returns {Number}
 */
Date.prototype.setMilliseconds = function(millisecondsValue) {};

/**
 * @syntax Date.UTC(year, month[, day[, hour[, minute[, second[, millisecond]]]]])
 * @param {Number} year
 * @param {Number} month
 * @param {Number} day
 * @param {Number} hour
 * @param {Number} minute
 * @param {Number} second
 * @param {Number} millisecond
 * @returns {Number}
 * @static
 */
Date.UTC = function(year, month) {};

/**
 * @syntax dateObj.getMinutes()
 * @returns {Number}
 */
Date.prototype.getMinutes = function() {};

/**
 * @syntax dateObj.getUTCFullYear()
 * @returns {Number}
 */
Date.prototype.getUTCFullYear = function() {};

/**
 * @syntax dateObj.getSeconds()
 * @returns {Number}
 */
Date.prototype.getSeconds = function() {};

/**
 * @syntax dateObj.getUTCDate()
 * @returns {Number}
 */
Date.prototype.getUTCDate = function() {};

/**
 * @syntax dateObj.toISOString()
 * @returns {String}
 */
Date.prototype.toISOString = function() {};

/**
 * @syntax dateObj.setTime(timeValue)
 * @param {Number} timeValue
 * @returns {Number}
 */
Date.prototype.setTime = function(timeValue) {};

/**
 * @syntax dateObj.setMonth(monthValue[, dayValue])
 * @returns {Number}
 */
Date.prototype.setMonth = function(monthValue) {};

/**
 * @syntax dateObj.getUTCMonth()
 * @returns {Number}
 */
Date.prototype.getUTCMonth = function() {};

/**
 * @syntax dateObj.setUTCDate(dayValue)
 * @param {Number} dayValue
 * @returns {Number}
 */
Date.prototype.setUTCDate = function(dayValue) {};

/**
 * @syntax dateObj.setUTCSeconds(secondsValue[, msValue])
 * @param {Number} secondsValue
 * @param {Number} msValue
 * @returns {Number}
 */
Date.prototype.setUTCSeconds = function(secondsValue) {};

/**
 * @syntax dateObj.getUTCMilliseconds()
 * @returns {Number}
 */
Date.prototype.getUTCMilliseconds = function() {};

/**
 * @syntax dateObj.getMilliseconds()
 * @returns {Number}
 */
Date.prototype.getMilliseconds = function() {};

/**
 * @syntax dateObj.getUTCHours()
 * @returns {Number}
 */
Date.prototype.getUTCHours = function() {};

/**
 * @syntax dateObj.getUTCMinutes()
 * @returns {Number}
 */
Date.prototype.getUTCMinutes = function() {};

/**
 * @syntax dateObj.setSeconds(secondsValue[, msValue])
 * @param {Number} secondsValue
 * @param {Number} msValue
 * @returns {Number}
 */
Date.prototype.setSeconds = function(secondsValue) {};

/**
 * @syntax dateObj.setUTCMonth(monthValue[, dayValue])
 * @param {Number} monthValue
 * @param {Number} dayValue
 * @returns {Number}
 */
Date.prototype.setUTCMonth = function(monthValue) {};

/**
 * @syntax dateObj.setDate(dayValue)
 * @param {Number} dayValue
 * @returns {Number}
 */
Date.prototype.setDate = function(dayValue) {};

/**
 * @deprecated
 * @syntax dateObj.toGMTString()
 * @returns {String}
 */
Date.prototype.toGMTString = function() {};

/**
 * @syntax dateObj.getHours()
 * @returns {Number}
 */
Date.prototype.getHours = function() {};

/**
 * @syntax dateObj.setUTCMilliseconds(millisecondsValue)
 * @param {Number} millisecondsValue
 * @returns {Number}
 */
Date.prototype.setUTCMilliseconds = function(millisecondsValue) {};

/**
 * @syntax dateObj.toJSON()
 * @returns {Number}
 */
Date.prototype.toJSON = function() {};

/**
 * Represents the Date prototype object.
 * @syntax Date.prototype
 * @static
 */
Date.prototype;

