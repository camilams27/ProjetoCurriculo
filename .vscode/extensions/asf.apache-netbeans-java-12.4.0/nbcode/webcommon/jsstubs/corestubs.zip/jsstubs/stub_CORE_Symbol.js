/**
 * @since ECMAScript6
 * @syntax Symbol([description])
 */
function Symbol() {
}
/**
 * @since ECMAScript6
 * @syntax Symbol.for(key)
 * @param {String} key
 * @returns {Symbol}
 * @static
 */
Symbol.for = function(key) {};

/**
 * @since ECMAScript6
 * @syntax Symbol().toString()
 * @returns {String}
 */
Symbol.prototype.toString = function() {};

/**
 * @since ECMAScript6
 * @returns {Number}
 * @static
 */
Symbol.search = new Number();

/**
 * @since ECMAScript6
 * @returns {undefined}
 * @static
 */
Symbol.toPrimitive;

/**
 * @since ECMAScript6
 * @returns {Array}
 * @static
 */
Symbol.split = new Array();

/**
 * @since ECMAScript6
 * @returns {String}
 * @static
 */
Symbol.replace = new String();

/**
 * @since ECMAScript6
 * @syntax Symbol.keyFor(sym)
 * @param {String} sym
 * @returns {String}
 * @static
 */
Symbol.keyFor = function(sym) {};

/**
 * @since ECMAScript6
 * @returns {Object}
 * @static
 */
Symbol.unscopables = new Object();

/**
 * @since ECMAScript6
 * @returns {Array}
 * @static
 */
Symbol.iterator = new Array();

/**
 * @since ECMAScript6
 * @returns {Array}
 * @static
 */
Symbol.match = new Array();

/**
 * @since ECMAScript6
 * @returns {Boolean}
 * @static
 */
Symbol.isConcatSpreadable = new Boolean();

/**
 * @since ECMAScript6
 * @returns {undefined}
 * @static
 */
Symbol.species;

/**
 * @since ECMAScript6
 * @syntax Symbol().valueOf()
 * @returns {undefined}
 */
Symbol.prototype.valueOf = function() {};

/**
 * Represents the Symbol prototype object.
 * @syntax Symbol.prototype
 * @static
 */
Symbol.prototype;

