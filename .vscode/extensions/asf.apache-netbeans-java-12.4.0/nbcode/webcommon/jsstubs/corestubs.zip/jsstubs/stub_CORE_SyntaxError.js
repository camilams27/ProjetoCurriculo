/**
 * @syntax new SyntaxError([message[, [, ]]])
 * @returns {Error}
 */
function SyntaxError() {
}
/**
 * @returns {String}
 */
SyntaxError.prototype.name = new String();

/**
 * @returns {String}
 */
SyntaxError.prototype.message = new String();

/**
 * @syntax e.toString()
 * @returns {String}
 */
SyntaxError.prototype.toString = function() {};

/**
 * Represents the SyntaxError prototype object.
 * @syntax SyntaxError.prototype
 * @static
 */
SyntaxError.prototype;

