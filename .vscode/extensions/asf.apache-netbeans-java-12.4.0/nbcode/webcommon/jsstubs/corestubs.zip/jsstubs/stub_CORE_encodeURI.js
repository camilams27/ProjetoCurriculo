/**
 * @syntax encodeURI(uri)
 * @param {String} uri
 * @returns {String}
 */
function encodeURI(uri) {};
