/**
 * @syntax new Boolean([value])
 * @returns {Boolean}
 */
function Boolean() {
}
/**
 * @syntax bool.valueOf()
 * @returns {Boolean}
 */
Boolean.prototype.valueOf = function() {};

/**
 * @syntax bool.toString()
 * @returns {String}
 */
Boolean.prototype.toString = function() {};

/**
 * Represents the Boolean prototype object.
 * @syntax Boolean.prototype
 * @static
 */
Boolean.prototype;

