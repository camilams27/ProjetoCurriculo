/**
 * @syntax NaN
 * @returns {Number}
 */
function NaN() {
}
/**
 * Represents the NaN prototype object.
 * @syntax NaN.prototype
 * @static
 */
NaN.prototype;

