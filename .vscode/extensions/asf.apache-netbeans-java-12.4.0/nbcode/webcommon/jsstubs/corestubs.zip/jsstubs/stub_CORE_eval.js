/**
 * @syntax eval(x)
 * @param {String} x
 * @returns {undefined}
 */
function eval(x) {};
