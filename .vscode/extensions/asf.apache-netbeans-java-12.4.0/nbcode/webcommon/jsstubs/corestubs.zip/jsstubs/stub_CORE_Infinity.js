/**
 * @syntax Infinity
 * @returns {Number}
 */
function Infinity() {
}
/**
 * Represents the Infinity prototype object.
 * @syntax Infinity.prototype
 * @static
 */
Infinity.prototype;

