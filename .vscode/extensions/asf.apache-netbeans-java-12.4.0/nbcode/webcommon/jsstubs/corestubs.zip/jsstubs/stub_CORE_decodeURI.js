/**
 * @syntax decodeURI(encodedURI)
 * @param {String} encodedURI
 * @returns {String}
 */
function decodeURI(encodedURI) {};
