/**
 * @syntax new Function ([arg1[, arg2[, ...argN]],] functionBody)
 * @returns {Function}
 */
function Function() {
}
/**
 * @syntax function.toString()
 * @returns {String}
 */
Function.prototype.toString = function() {};

/**
 * @since ECMAScript6
 * @returns {String}
 * @static
 */
Function.name = new String();

/**
 * @syntax fun.call(thisArg[, arg1[, arg2[, ...]]])
 * @param {Object} thisArg
 * @returns {String}
 */
Function.prototype.call = function(thisArg) {};

/**
 * @deprecated
 * @returns {Array}
 * @static
 */
Function.arguments = new Array();

/**
 * @returns {Number}
 * @static
 */
Function.length = new Number();

/**
 * @syntax fun.apply(thisArg, [argsArray])
 * @param {Object} thisArg
 * @param {Array} argsArray
 * @returns {Array}
 */
Function.prototype.apply = function(thisArg) {};

/**
 * Represents the Function prototype object.
 * @syntax Function.prototype
 * @static
 */
Function.prototype;

