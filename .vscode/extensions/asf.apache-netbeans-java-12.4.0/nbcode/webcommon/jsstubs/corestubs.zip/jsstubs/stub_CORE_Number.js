/**
 * @syntax new Number(value)
 * @param {Object} value
 * @returns {Number}
 */
function Number(value) {
}
/**
 * @since ECMAScript6
 * @syntax Number.isSafeInteger(testValue)
 * @param {Number} testValue
 * @returns {Boolean}
 * @static
 */
Number.isSafeInteger = function(testValue) {};

/**
 * @syntax numObj.toString([radix])
 * @param {Number} radix
 * @returns {String}
 */
Number.prototype.toString = function() {};

/**
 * @syntax numObj.toFixed([digits])
 * @param {Number} digits
 * @returns {Number}
 */
Number.prototype.toFixed = function() {};

/**
 * @returns {Number}
 * @static
 */
Number.MIN_VALUE = new Number();

/**
 * @since ECMAScript6
 * @syntax Number.isFinite(value)
 * @param {undefined} value
 * @returns {Boolean}
 * @static
 */
Number.isFinite = function(value) {};

/**
 * @syntax numObj.valueOf()
 * @returns {Number}
 */
Number.prototype.valueOf = function() {};

/**
 * @since ECMAScript6
 * @returns {Number}
 * @static
 */
Number.MAX_SAFE_INTEGER = new Number();

/**
 * @since ECMAScript6
 * @returns {Number}
 * @static
 */
Number.MIN_SAFE_INTEGER = new Number();

/**
 * @syntax numObj.toPrecision([precision])
 * @param {Number} precision
 * @returns {Number}
 */
Number.prototype.toPrecision = function() {};

/**
 * @since ECMAScript6
 * @returns {Number}
 * @static
 */
Number.EPSILON = new Number();

/**
 * @returns {Number}
 * @static
 */
Number.NaN = new Number();

/**
 * @returns {String}
 * @static
 */
Number.POSITIVE_INFINITY = new String();

/**
 * @syntax numObj.toLocaleString([locales [, options]])
 * @param {Array} locales
 * @param {String} options
 * @returns {String}
 */
Number.prototype.toLocaleString = function() {};

/**
 * @since ECMAScript6
 * @syntax Number.parseInt(string[, radix])
 * @param {String} string
 * @returns {Number}
 * @static
 */
Number.parseInt = function(string) {};

/**
 * @syntax numObj.toExponential([fractionDigits])
 * @param {Number} fractionDigits
 * @returns {Number}
 */
Number.prototype.toExponential = function() {};

/**
 * @returns {Number}
 * @static
 */
Number.MAX_VALUE = new Number();

/**
 * @since ECMAScript6
 * @syntax Number.isInteger(value)
 * @param {Number} value
 * @returns {Boolean}
 * @static
 */
Number.isInteger = function(value) {};

/**
 * @since ECMAScript6
 * @syntax Number.parseFloat(string)
 * @param {String} string
 * @returns {Number}
 * @static
 */
Number.parseFloat = function(string) {};

/**
 * @returns {String}
 * @static
 */
Number.NEGATIVE_INFINITY = new String();

/**
 * @since ECMAScript6
 * @syntax Number.isNaN(value)
 * @param {String} value
 * @returns {Boolean}
 * @static
 */
Number.isNaN = function(value) {};

/**
 * Represents the Number prototype object.
 * @syntax Number.prototype
 * @static
 */
Number.prototype;

