/**
 * @syntax decodeURIComponent(encodedURIComponent)
 * @param {String} encodedURIComponent
 * @returns {String}
 */
function decodeURIComponent(encodedURIComponent) {};
