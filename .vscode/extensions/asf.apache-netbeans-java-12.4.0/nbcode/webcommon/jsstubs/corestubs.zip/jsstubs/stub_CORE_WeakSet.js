/**
 * @since ECMAScript6
 * @syntax new WeakSet([iterable])
 */
function WeakSet() {
}
/**
 * @since ECMAScript6
 * @syntax ws.has(value)
 * @param {Object} value
 * @returns {Boolean}
 */
WeakSet.prototype.has = function(value) {};

/**
 * @since ECMAScript6
 * @syntax ws.delete(value)
 * @param {Object} value
 * @returns {Boolean}
 */
WeakSet.prototype.delete = function(value) {};

/**
 * @since ECMAScript6
 * @syntax ws.add(value)
 * @param {Object} value
 * @returns {Object}
 */
WeakSet.prototype.add = function(value) {};

/**
 * Represents the WeakSet prototype object.
 * @syntax WeakSet.prototype
 * @static
 */
WeakSet.prototype;

