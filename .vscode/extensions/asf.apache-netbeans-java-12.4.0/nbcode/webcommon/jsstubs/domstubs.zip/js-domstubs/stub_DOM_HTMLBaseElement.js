/**
 * Document base URI [IETF RFC 2396]. See the BASE element definition in HTML 4.01.
 */
var HTMLBaseElement = {
}
/**
 * The default target frame. See the target attribute definition in HTML 4.01.
 * @syntax hTMLBaseElement.target
 * @returns {String} 
 */
HTMLBaseElement.prototype.target = new String();

/**
 * The base URI [IETF RFC 2396]. See the href attribute definition in HTML 4.01.
 * @syntax hTMLBaseElement.href
 * @returns {String} 
 */
HTMLBaseElement.prototype.href = new String();

/**
 * Represents the HTMLBaseElement prototype object.
 * @syntax HTMLBaseElement.prototype
 * @static
 */
HTMLBaseElement.prototype;

