/**
 * Range operations may throw a RangeException as specified in their method descriptions.
 */
var RangeException = {
}
/**
 * If the boundary-points of a Range do not meet specific requirements.
 * @syntax RangeException.BAD_BOUNDARYPOINTS_ERR
 * @returns {Number} 
 * @static
 */
RangeException.BAD_BOUNDARYPOINTS_ERR = new Number();

/**
 * If the container of an boundary-point of a Range is being set to either a node of an invalid type or a node with an ancestor of an invalid type.
 * @syntax RangeException.INVALID_NODE_TYPE_ERR
 * @returns {Number} 
 * @static
 */
RangeException.INVALID_NODE_TYPE_ERR = new Number();

/**
 * Represents the RangeException prototype object.
 * @syntax RangeException.prototype
 * @static
 */
RangeException.prototype;

