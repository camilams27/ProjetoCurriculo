/**
 * Organizes form controls into logical groups. See the FIELDSET element definition in HTML 4.01.
 */
var HTMLFieldSetElement = {
}
/**
 * Returns the FORM element containing this control. Returns null if this control is not within the context of a form.
 * @syntax hTMLFieldSetElement.form
 * @returns {HTMLFormElement} 
 */
HTMLFieldSetElement.prototype.form = new HTMLFormElement();

/**
 * Represents the HTMLFieldSetElement prototype object.
 * @syntax HTMLFieldSetElement.prototype
 * @static
 */
HTMLFieldSetElement.prototype;

