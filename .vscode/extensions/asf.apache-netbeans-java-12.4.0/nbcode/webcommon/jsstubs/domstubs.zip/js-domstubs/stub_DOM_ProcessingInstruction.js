/**
 * The ProcessingInstruction interface represents a "processing instruction", used in XML as a way to keep processor-specific information in the text of the document.No lexical check is done on the content of a processing instruction and it is therefore possible to have the character sequence "?>" in the content, which is illegal a processing instruction per section 2.6 of [XML 1.0]. The presence of this character sequence must generate a fatal error during serialization.
 */
var ProcessingInstruction = {
}
/**
 * The content of this processing instruction. This is from the first non white space character after the target to the character immediately preceding the ?>. Exceptions on setting DOMException NO_MODIFICATION_ALLOWED_ERR: Raised when the node is readonly.
 * @syntax processingInstruction.data
 * @returns {String} 
 */
ProcessingInstruction.prototype.data = new String();

/**
 * The target of this processing instruction. XML defines this as being the first token following the markup that begins the processing instruction.
 * @syntax processingInstruction.target
 * @returns {String} 
 */
ProcessingInstruction.prototype.target = new String();

/**
 * Represents the ProcessingInstruction prototype object.
 * @syntax ProcessingInstruction.prototype
 * @static
 */
ProcessingInstruction.prototype;

