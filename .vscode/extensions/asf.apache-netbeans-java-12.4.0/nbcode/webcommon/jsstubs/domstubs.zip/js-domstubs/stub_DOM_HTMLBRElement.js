/**
 * Force a line break. See the BR element definition in HTML 4.01.
 */
var HTMLBRElement = {
}
/**
 * Control flow of text around floats. See the clear attribute definition in HTML 4.01. This attribute is deprecated in HTML 4.01.
 * @syntax hTMLBRElement.clear
 * @returns {String} 
 */
HTMLBRElement.prototype.clear = new String();

/**
 * Represents the HTMLBRElement prototype object.
 * @syntax HTMLBRElement.prototype
 * @static
 */
HTMLBRElement.prototype;

