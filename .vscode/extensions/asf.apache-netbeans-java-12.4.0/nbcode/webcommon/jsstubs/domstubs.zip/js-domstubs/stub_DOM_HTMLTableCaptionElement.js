/**
 * Table caption See the CAPTION element definition in HTML 4.01.
 */
var HTMLTableCaptionElement = {
}
/**
 * Caption alignment with respect to the table. See the align attribute definition in HTML 4.01. This attribute is deprecated in HTML 4.01.
 * @syntax hTMLTableCaptionElement.align
 * @returns {String} 
 */
HTMLTableCaptionElement.prototype.align = new String();

/**
 * Represents the HTMLTableCaptionElement prototype object.
 * @syntax HTMLTableCaptionElement.prototype
 * @static
 */
HTMLTableCaptionElement.prototype;

