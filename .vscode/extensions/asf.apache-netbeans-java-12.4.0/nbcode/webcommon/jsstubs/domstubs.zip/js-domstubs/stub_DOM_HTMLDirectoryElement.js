/**
 * Directory list. See the DIR element definition in HTML 4.01. This element is deprecated in HTML 4.01.
 */
var HTMLDirectoryElement = {
}
/**
 * Reduce spacing between list items. See the compact attribute definition in HTML 4.01. This attribute is deprecated in HTML 4.01.
 * @syntax hTMLDirectoryElement.compact
 * @returns {boolean} 
 */
HTMLDirectoryElement.prototype.compact = new boolean();

/**
 * Represents the HTMLDirectoryElement prototype object.
 * @syntax HTMLDirectoryElement.prototype
 * @static
 */
HTMLDirectoryElement.prototype;

