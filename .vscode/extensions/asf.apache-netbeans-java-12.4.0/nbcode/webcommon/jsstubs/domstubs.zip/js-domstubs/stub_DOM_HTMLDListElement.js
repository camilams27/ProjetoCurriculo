/**
 * Definition list. See the DL element definition in HTML 4.01.
 */
var HTMLDListElement = {
}
/**
 * Reduce spacing between list items. See the compact attribute definition in HTML 4.01. This attribute is deprecated in HTML 4.01.
 * @syntax hTMLDListElement.compact
 * @returns {boolean} 
 */
HTMLDListElement.prototype.compact = new boolean();

/**
 * Represents the HTMLDListElement prototype object.
 * @syntax HTMLDListElement.prototype
 * @static
 */
HTMLDListElement.prototype;

