/**
 * The CSSFontFaceRule interface represents a @font-face rule in a CSS style sheet. The @font-face rule is used to hold a set of font descriptions.
 */
var CSSFontFaceRule = {
}
/**
 * The declaration-block of this rule.
 * @syntax cSSFontFaceRule.style
 * @returns {CSSStyleDeclaration} 
 */
CSSFontFaceRule.prototype.style = new CSSStyleDeclaration();

/**
 * Represents the CSSFontFaceRule prototype object.
 * @syntax CSSFontFaceRule.prototype
 * @static
 */
CSSFontFaceRule.prototype;

